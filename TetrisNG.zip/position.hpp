#pragma once

class Position{ //Defines the Variables and Constructors of The Class B
    public:
    Position(int row, int column);
    int row;
    int column;

};